(function () {
  var calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (calm) return;

  /* 1. Tilt + glare on every card */
  if (false) {
    document.querySelectorAll('.soft-card').forEach(function (el) {
      el.setAttribute('data-tilt', '');
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        el.style.setProperty('--ry', ((x - .5) * 5).toFixed(2) + 'deg');
        el.style.setProperty('--rx', ((.5 - y) * 5).toFixed(2) + 'deg');
        el.style.setProperty('--gx', (x * 100) + '%');
        el.style.setProperty('--gy', (y * 100) + '%');
        el.classList.add('is-tilting');
      });
      el.addEventListener('pointerleave', function () { el.classList.remove('is-tilting'); });
    });
  }

  /* 2. Layered 3D stages: home hero, home about photo, About page portrait + session photo */
  function makeStage(stage, ry, rx) {
    return;
    var kids = Array.prototype.slice.call(stage.children);
    stage.classList.add('stage3d');
    var inner = document.createElement('div');
    inner.className = 'stage3d-inner relative';
    kids.forEach(function (k) { inner.appendChild(k); });
    stage.appendChild(inner);
    kids.forEach(function (k) {
      var c = k.className || '';
      if (c.indexOf('z-20') > -1) k.classList.add('z-front');
      else if (c.indexOf('absolute') > -1 || c.indexOf('-z-0') > -1) k.classList.add('z-back');
      else k.classList.add('z-main');
    });
    stage.addEventListener('pointermove', function (e) {
      var r = stage.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      inner.classList.add('moving');
      inner.style.transform = 'rotateY(' + (x * ry) + 'deg) rotateX(' + (-y * rx) + 'deg)';
    });
    stage.addEventListener('pointerleave', function () { inner.classList.remove('moving'); inner.style.transform = ''; });
  }
  var heroImg = document.querySelector('img[src*="sakshi-hero"]');
  if (heroImg) makeStage(heroImg.closest('.relative.mx-auto'), 8, 6);
  ['sakshi-about-summary', 'sakshi-portrait'].forEach(function (n) {
    var im = document.querySelector('img[src*="' + n + '"]');
    if (im) makeStage(im.closest('.lg\\:col-span-5'), 7, 5);
  });
  var sess = document.querySelector('img[src*="counselling-session"]');
  if (sess) makeStage(sess.parentElement, 5, 4);

  /* 3. Floating 3D orbs behind the home hero (Three.js, desktop only) */
  var aboutImg = document.querySelector('img[src*="sakshi-portrait"]');
  var hero = (heroImg || aboutImg) && (heroImg || aboutImg).closest('section');
  if (hero && innerWidth > 900) {
    var s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    s.onload = function () {
      var cv = document.createElement('canvas'); cv.id = 'orbs3d';
      hero.classList.add('has-orbs'); hero.insertBefore(cv, hero.firstChild);
      var R = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
      R.setPixelRatio(Math.min(devicePixelRatio, 2));
      var S = new THREE.Scene(), C = new THREE.PerspectiveCamera(40, 1, .1, 100); C.position.z = 14;
      S.add(new THREE.AmbientLight(0xfff4e6, .8));
      var L = new THREE.DirectionalLight(0xffffff, .9); L.position.set(4, 6, 8); S.add(L);
      var cols = [0xb49277, 0xd8c2b0, 0x9b4922, 0xe3d6c4, 0xcaad95, 0xc27a52], orbs = [];
      [[-7.5,2.8,-2,1.5],[7.8,-3,-3,1.9],[-3.2,-3.6,0,.8],[3.5,3.6,-1,.6],[-9,-1.5,-4,1.1],[9.5,3.2,-5,.9],[-5.5,-0.5,-6,2.2],[5.2,0.8,-7,1.3],[0.5,4.4,-3,.5],[-1.5,-4.4,-2,.7],[10.5,-0.5,-2,.6],[-10.5,3.4,-3,.7]].forEach(function (p, i) {
        var m = new THREE.Mesh(new THREE.SphereGeometry(p[3], 48, 48),
          new THREE.MeshStandardMaterial({ color: cols[i % cols.length], roughness: .35, metalness: .05, transparent: true, opacity: .6 }));
        m.position.set(p[0], p[1], p[2]); m.userData = { y: p[1], x: p[0], o: i * 1.7 }; S.add(m); orbs.push(m);
      });
      function size() { var w = hero.clientWidth, h = hero.clientHeight; R.setSize(w, h, false); C.aspect = w / h; C.updateProjectionMatrix(); }
      size(); addEventListener('resize', size);
      var mx = 0, my = 0;
      addEventListener('pointermove', function (e) { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; });
      var visible = true;
      new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }).observe(hero);
      (function loop(t) {
        requestAnimationFrame(loop); if (!visible || document.hidden) return;
        t *= .001;
        orbs.forEach(function (m) {
          m.position.y = m.userData.y + Math.sin(t * .6 + m.userData.o) * .8;
          m.position.x = m.userData.x + Math.cos(t * .4 + m.userData.o) * .25;
        });
        C.position.x += (mx * 2.6 - C.position.x) * .04; C.position.y += (-my * 1.6 - C.position.y) * .04;
        C.lookAt(0, 0, 0); R.render(S, C);
      })(0);
    };
    document.head.appendChild(s);
  }

  /* 4. Scroll-linked depth + parallax orbs on every section below the hero */
  (function () {
    var small = innerWidth < 760, amp = small ? .6 : 1, secs = [].slice.call(document.querySelectorAll('section')), items = [], orbs = [];
    function layoutY(el) { var y = 0; while (el) { y += el.offsetTop; el = el.offsetParent; } return y; }

    secs.forEach(function (sec, si) {
      if (si === 0) return;
      sec.classList.add('has-depth');
      var flip = si % 2, P = [[-3, 10, 170, .16], [97, 52, 250, -.11], [48, 84, 90, .26]];
      P.forEach(function (p, k) {
        if (small && k === 1) return;
        var o = document.createElement('span'), s = p[2] * (small ? .55 : 1), x = flip ? 100 - p[0] : p[0];
        o.className = 'orb3d' + (k === 2 ? ' orb-rust' : ''); o.setAttribute('aria-hidden', 'true');
        o.style.cssText = 'width:' + s + 'px;height:' + s + 'px;top:' + p[1] + '%;left:calc(' + x + '% - ' + (s / 2) + 'px)';
        sec.insertBefore(o, sec.firstChild);
        orbs.push({ el: o, sec: sec, sp: p[3] });
      });
    });

    var ticking = false;
    function frame() {
      ticking = false;
      var vh = innerHeight, sy = scrollY, ps = [], os = [], i;
      for (i = 0; i < items.length; i++) { var it = items[i]; if (!it.el.offsetParent) { ps.push(null); continue; }
        ps.push(((layoutY(it.el) + it.el.offsetHeight / 2 - sy) - vh / 2) / (vh / 2)); }
      for (i = 0; i < orbs.length; i++) os.push(layoutY(orbs[i].sec) + orbs[i].sec.offsetHeight / 2 - sy - vh / 2);

      for (i = 0; i < items.length; i++) {
        var p = ps[i], el = items[i].el, e, rx = 0, tz = 0, ty = 0, o = 1;
        if (p === null) continue;
        if (p > 0) { p += items[i].lag; e = Math.min(Math.max(0, p - .25) / .75, 1.4);
          rx = e * 16 * amp; tz = -e * 110 * amp; ty = e * 28; o = 1 - Math.min(e, 1) * .7; }
        else { e = Math.min(Math.max(0, -p - .35) / .65, 1.4);
          rx = -e * 8 * amp; tz = -e * 80 * amp; o = 1 - Math.min(e, 1) * .6; }
        if (e === 0) { el.style.translate = ''; el.style.rotate = ''; el.style.opacity = ''; }
        else { el.style.translate = '0 ' + ty.toFixed(1) + 'px ' + tz.toFixed(1) + 'px';
               el.style.rotate = '1 0 0 ' + rx.toFixed(2) + 'deg'; el.style.opacity = o.toFixed(2); }
      }
      for (i = 0; i < orbs.length; i++) {
        var d = os[i];
        orbs[i].el.style.translate = '0 ' + (-d * orbs[i].sp).toFixed(1) + 'px';
        orbs[i].el.style.rotate = '1 1 0 ' + (d * .05).toFixed(1) + 'deg';
      }
    }
    function req() { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }
    addEventListener('scroll', req, { passive: true }); addEventListener('resize', req); addEventListener('load', req);
    frame();
  })();
})();
